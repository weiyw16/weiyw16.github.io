{
    "title":"Atlassian Marketplace Plugins",
    "link":"https://marketplace.atlassian.com/vendors/1017039",
    "image":"/img/marketplace-summary.webp",
    "description":"Multiple plugins used by thousands of teams that provide enhanced functionality of Atlassian’s core products (primarily JIRA and Bamboo) to enrich CI/CD capabilities, DevOps automation, or productivity. Functionality spans user interface, web services and persistence.",
    "tags":["Java", "Spring", "REST APIs", "Javascript", "Atlassian Developer Ecosystem", "Bamboo", "JIRA", "Bitbucket", "Confluence","DevOps"],
    "fact":"1,500+ Active installations across large and small companies."
}


Multiple plugins used by thousands of teams that provide enhanced functionality of Atlassian’s core products (primarily JIRA and Bamboo) to enrich CI/CD capabilities, DevOps automation, or productivity. Functionality spans user interface, web services and persistence.
